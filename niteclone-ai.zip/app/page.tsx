export default function Home() {
  return <div style={{color:'white',background:'black',height:'100vh'}}>NiteClone AI Running</div>
}