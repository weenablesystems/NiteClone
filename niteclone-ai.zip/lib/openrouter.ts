export async function chatWithAI(message: string) {
  const res = await fetch("https://openrouter.ai/api/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: "venice-uncensored",
      messages: [{ role: "user", content: message }]
    })
  })
  const data = await res.json()
  return data.choices[0].message.content
}